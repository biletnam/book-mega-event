correct all the links

other things are done